This is a snapshot of the spreadsheets found at the California Department of Education's Private Schools directory:

    http://www.cde.ca.gov/ds/si/ps/


The files were gathered and zipped like so:

    wget --recursive --level 1 --no-directories --accept xls
        http://www.cde.ca.gov/ds/si/ps/
    zip cdeprivateschools.zip README.md *.xls



- Dan Nguyen, dan@danwin.com, 2015-07-06
